import ray
import networkx as nx

from utils import register, Type, fetch


@register(output_type=Type.GRAPH)
@ray.remote
def gnp_random_graph(args, output_refs, locators):
    assert "n" in args and "p" in args, "Missing arguments for RandGraphGeneration"
    n, p = args["n"], args["p"]
    return (nx.gnp_random_graph(n, p), )
