import sys

from graph_generation import *
from graph_processing import *
from storage import fetch_job_info, wait_and_save_in_hdfs
from safety import topological_sort, validate_type


def rearrange_job_info_format(job_info):
    new_job_info = {}
    for node in job_info['nodes']:
        t = new_job_info[node['mark']] = {}
        t['name'] = node['name']
        t['args'] = {}
        for attribute in node['simpleAttributes']:
            t['args'][attribute['name']] = attribute['value']
        t['locators'] = {}
        for anchor in node['inputAnchors']:
            t['locators'][anchor['seq']] = (anchor['sourceAnchor']['nodeMark'], anchor['sourceAnchor']['seq'])
    return new_job_info


def main():
    assert len(sys.argv) == 2, "There is no command line args for execution_engine.py"
    key = sys.argv[1]
    user_id, title = key.split('-')
    job_info = fetch_job_info(user_id, title)

    # define a sequence of execution
    toposorted = topological_sort(job_info)
    print("Passed topological sort")

    # Validate the connected nodes
    validate_type(job_info)
    print("Passed type check")

    new_job_info = rearrange_job_info_format(job_info)

    # Topological sort ensured that the prerequisites are satisfied
    output_refs = dict()
    for node in toposorted:
        name, args, locators = new_job_info[node]['name'],  new_job_info[node]['args'], new_job_info[node]['locators']
        output_ref = eval("{}".format(name)).remote(args, output_refs, locators)
        output_refs[node] = output_ref

    print(wait_and_save_in_hdfs(key, output_refs))


if __name__ == "__main__":
    main()
