import ray
import hdfs
import pymongo
from utils import adjust_the_output_to_json


def fetch_job_info(user_id, title):
    mongo_client = pymongo.MongoClient("mongodb://bdapadmin:bdapadmin@bdap-cluster-01:27017/bdap_info?maxPoolSize=256")
    ray_collection = mongo_client.get_database("bdap_info").get_collection("rayJobInfo")
    job_info = ray_collection.find_one({'userId': user_id, 'title': title})
    if job_info is None:
        raise ValueError("Work flow does not exists.")
    return job_info


def wait_and_save_in_hdfs(key, output_refs):
    hdfs_client = hdfs.Client("http://10.105.222.241:9870")
    outputs = {}
    while len(output_refs) > 0:
        ready_ref_lt, _ = ray.wait(list(output_refs.values()))
        ready_ref = ready_ref_lt[0]
        for k, v in output_refs.items():
            if v == ready_ref:
                output = ','.join([adjust_the_output_to_json(item) for item in ray.get(v)])
                with hdfs_client.write("/raytmp/{}-{}.json".format(key, k), encoding='UTF8') as writer:
                    writer.write(output)
                output_refs.pop(k)
                outputs[k] = output
                break
    return outputs
