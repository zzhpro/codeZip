import ray
import networkx as nx
from utils import register, Type


@register(input_type=Type.GRAPH, output_type=Type.DICT)
@ray.remote
def degree_centrality(args, inp, node_outputs):
    G = ray.get(node_outputs[inp[0][0]])
    result = dict()
    result["degree_centrality"] = nx.degree_centrality(G)
    if isinstance(G, nx.DiGraph):
        result["in_degree_centrality"] = nx.in_degree_centrality(G)
        result["out_degree_centrality"] = nx.out_degree_centrality(G)
    return result


@register(input_type=Type.GRAPH, output_type=Type.DICT)
@ray.remote
def closeness_centrality(args, inp, node_outputs):
    G = ray.get(node_outputs[inp[0][0]])
    return {"closeness_centrality": nx.closeness_centrality(G)}


@register(input_type=Type.GRAPH, output_type=Type.DICT)
@ray.remote
def betweenness_centrality(args, inp, node_outputs):
    G = ray.get(node_outputs[inp[0][0]])
    return {"betweenness_centrality": nx.betweenness_centrality(G)}


@register(input_type=Type.GRAPH, output_type=Type.DICT)
@ray.remote
def eigenvector_centrality(args, inp, node_outputs):
    G = ray.get(node_outputs[inp[0][0]])
    return {"eigenvector_centrality": nx.eigenvector_centrality(G)}


@register(input_type=Type.GRAPH, output_type=Type.DICT)
@ray.remote
def pagerank_centrality(args, inp, node_outputs):
    G = ray.get(node_outputs[inp[0][0]])
    return {"pagerank_centrality": nx.pagerank(G)}
