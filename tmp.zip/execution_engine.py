import sys
import json
import ray
import hdfs
from typing import Dict, List

from GraphGeneration import *
from GraphProcessing import *


def topological_sort(nodes: Dict, edges: List):
    # Produce a topological sort of the nodes
    adj_lt, indegree = dict(), dict()
    for node in nodes:
        adj_lt[node] = []
        indegree[node] = 0

    for start, end in edges:
        adj_lt[start].append(end)
        indegree[end] += 1

    zero_in_nodes = []
    for node in nodes:
        if indegree[node] == 0:
            zero_in_nodes.append(node)

    toposorted = []
    while len(toposorted) < len(nodes):
        if len(zero_in_nodes) == 0:
            raise ValueError("Input graph contains loop")

        new_zero_in_nodes = []
        for node in zero_in_nodes:
            for nxt in adj_lt[node]:
                indegree[nxt] -= 1
                if indegree[nxt] == 0:
                    new_zero_in_nodes.append(nxt)

        toposorted.extend(zero_in_nodes)
        zero_in_nodes = new_zero_in_nodes

    return toposorted


def validate_type(nodes: Dict, edges: List):
    for desc in nodes.values():
        func = eval(desc["type"])
        if len(desc["input"]) != len(func.input_type):
            raise TypeError("Flow type miss match")
        for (source_id, oindex), itype in zip(desc["input"], func.input_type):
            otype = eval(nodes[source_id]["type"]).output_type[oindex]
            if otype != itype:
                raise TypeError("Flow type miss match")


def main():
    # Rebuild the json, check necessary fields
    assert len(sys.argv) == 2, "There is no command line args for execution_engine.py"

    key = sys.argv[1]
    hdfs_client = hdfs.Client("http://10.105.222.241:9870")
    with hdfs_client.read("/raytmp/{}.json".format(key), encoding="UTF8") as reader:
        json_string = reader.read()

    graph_desc = json.loads(json_string)
    assert "nodes" in graph_desc, "There is no \"nodes\""
    assert "edges" in graph_desc, "There is no \"edges\""

    # define a sequence of execution
    toposorted = topological_sort(graph_desc["nodes"], graph_desc["edges"])
    print("Passed topological sort")

    validate_type(graph_desc["nodes"], graph_desc["edges"])
    print("Passed type check")

    # Topological sort ensured that the prerequisites are satisfied
    node_outputs = dict()
    for node in toposorted:
        desc = graph_desc["nodes"][node]
        output_ref = eval("{0}".format(desc['type'])).remote(desc['args'], desc['input'], node_outputs)
        node_outputs[node] = output_ref

    node_outputs = {k: ray.get(v) for k, v in node_outputs.items()}
    print(node_outputs)

    result_string = str(node_outputs)
    with hdfs_client.write("/raytmp/{}_result.json".format(key), encoding="UTF8") as writer:
        writer.write(result_string)


if __name__ == "__main__":
    main()
