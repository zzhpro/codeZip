import ray
import networkx as nx

from utils import register, Type


@register(output_type=[Type.GRAPH])
@ray.remote
def gnp_random_graph(args, inp, node_outputs):
    assert "n" in args and "p" in args, "Missing arguments for RandGraphGeneration"
    n, p = args["n"], args["p"]
    return nx.gnp_random_graph(n, p)